
void arrowMove();
void moveRight();
void moveLeft();
void movePlayer(char input);
void arrowMake(int i);
void printScore();
void arrowColorChange();
void color();